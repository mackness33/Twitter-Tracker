from .User.service import UsersService
users = UsersService()

from .Dash import WareHouseService
warehouseService = WareHouseService()
